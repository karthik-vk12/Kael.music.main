package com.devxrohan.smusic.constants

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import java.time.LocalDateTime
import java.time.ZoneOffset

val DarkModeKey = stringPreferencesKey("darkMode")

val UserNameKey = stringPreferencesKey("user_name")

val SlimNavBarKey = booleanPreferencesKey("slimNavBar")
val ShowGalaxySliderKey = booleanPreferencesKey("showGalaxySlider")
val GridItemsSizeKey = stringPreferencesKey("gridItemSize")
val SliderStyleKey = stringPreferencesKey("sliderStyle")
val PlayerScreenStyleKey = stringPreferencesKey("playerScreenStyle")
val HideVideoKey = booleanPreferencesKey("hideVideo")

val ColourfullPlayerColorKey = intPreferencesKey("colourfullPlayerColor")

enum class SliderStyle {
    DEFAULT,
    SQUIGGLY,
    SLIM,
}

enum class PlayerScreenStyle {
    PAPER,
    CLASSIC,
    MODERN,
    SPOTIFY,
    LIQUID,
    CLOUDGLOW,
    FROST,
    FOLD,
    GROOVE,
    POPSY,
    MINIMAL,
    COLOURFULL,
    APPLE,
    GALAXY,
    IOS_STYLED
}

const val SYSTEM_DEFAULT = "SYSTEM_DEFAULT"
val ContentLanguageKey = stringPreferencesKey("contentLanguage")
val ContentCountryKey = stringPreferencesKey("contentCountry")
val EnableKugouKey = booleanPreferencesKey("enableKugou")
val EnableLrcLibKey = booleanPreferencesKey("enableLrclib")
val MusicProviderKey = stringPreferencesKey("musicProvider")
val HideExplicitKey = booleanPreferencesKey("hideExplicit")
val LastNewReleaseCheckKey = longPreferencesKey("last_new_release_check")
val SkippedUpdateVersionCodeKey = intPreferencesKey("skipped_update_version_code")
val EnableUpdateNotificationKey = booleanPreferencesKey("enable_update_notification")
val LastNotifiedVersionKey = stringPreferencesKey("last_notified_version")
val LastUpdateCheckKey = longPreferencesKey("last_update_check")
val AnnouncementsCacheKey = stringPreferencesKey("announcements_cache_json")
val SeenAnnouncementIdsKey = stringPreferencesKey("seen_announcement_ids")
val minPlaybackDurKey = intPreferencesKey("minPlaybackDur")
val ProxyEnabledKey = booleanPreferencesKey("proxyEnabled")
val UseRotatingProxyKey = booleanPreferencesKey("useRotatingProxy")
val LowDataModeKey = booleanPreferencesKey("lowDataMode")
val DisableAnimationsKey = booleanPreferencesKey("disableAnimations")
val OnboardingCompletedKey = booleanPreferencesKey("onboardingCompleted")
val ProxyUrlKey = stringPreferencesKey("proxyUrl")
val ProxyTypeKey = stringPreferencesKey("proxyType")
val YtmSyncKey = booleanPreferencesKey("ytmSync")

val AudioQualityKey = stringPreferencesKey("audioQuality")

enum class AudioQuality {
    AUTO,
    HIGH,
    MAX,
    LOW,
}

val PersistentQueueKey = booleanPreferencesKey("persistentQueue")
val PermanentShuffleKey = booleanPreferencesKey("permanentShuffle")
val SkipSilenceKey = booleanPreferencesKey("skipSilence")
val AudioNormalizationKey = booleanPreferencesKey("audioNormalization")
val AutoLoadMoreKey = booleanPreferencesKey("autoLoadMore")
val SimilarContent = booleanPreferencesKey("similarContent")
val AutoSkipNextOnErrorKey = booleanPreferencesKey("autoSkipNextOnError")
val StopMusicOnTaskClearKey = booleanPreferencesKey("stopMusicOnTaskClear")

val MaxImageCacheSizeKey = intPreferencesKey("maxImageCacheSize")
val MaxSongCacheSizeKey = intPreferencesKey("maxSongCacheSize")

val DisableLoadMoreWhenRepeatAllKey = booleanPreferencesKey("disableLoadMoreWhenRepeatAll")
val ScrobbleDelayPercentKey = floatPreferencesKey("scrobbleDelayPercent")
val ScrobbleMinSongDurationKey = intPreferencesKey("scrobbleMinSongDuration")
val ScrobbleDelaySecondsKey = intPreferencesKey("scrobbleDelaySeconds")
val EnableLastFMScrobblingKey = booleanPreferencesKey("enableLastFMScrobbling")
val LastFMUseNowPlaying = booleanPreferencesKey("lastFMUseNowPlaying")
val AudioOffload = booleanPreferencesKey("audioOffload")

val RotateBackgroundKey = booleanPreferencesKey("rotate_background")

val PauseListenHistoryKey = booleanPreferencesKey("pauseListenHistory")
val PauseSearchHistoryKey = booleanPreferencesKey("pauseSearchHistory")
val DisableScreenshotKey = booleanPreferencesKey("disableScreenshot")

val ChipSortTypeKey = stringPreferencesKey("chipSortType")
val SongSortTypeKey = stringPreferencesKey("songSortType")
val SongSortDescendingKey = booleanPreferencesKey("songSortDescending")
val PlaylistSongSortTypeKey = stringPreferencesKey("playlistSongSortType")
val PlaylistSongSortDescendingKey = booleanPreferencesKey("playlistSongSortDescending")
val AutoPlaylistSongSortTypeKey = stringPreferencesKey("autoPlaylistSongSortType")
val AutoPlaylistSongSortDescendingKey = booleanPreferencesKey("autoPlaylistSongSortDescending")
val ArtistSortTypeKey = stringPreferencesKey("artistSortType")
val ArtistSortDescendingKey = booleanPreferencesKey("artistSortDescending")
val AlbumSortTypeKey = stringPreferencesKey("albumSortType")
val AlbumSortDescendingKey = booleanPreferencesKey("albumSortDescending")
val PlaylistSortTypeKey = stringPreferencesKey("playlistSortType")
val PlaylistSortDescendingKey = booleanPreferencesKey("playlistSortDescending")
val ArtistSongSortTypeKey = stringPreferencesKey("artistSongSortType")
val ArtistSongSortDescendingKey = booleanPreferencesKey("artistSongSortDescending")
val MixSortTypeKey = stringPreferencesKey("mixSortType")
val MixSortDescendingKey = booleanPreferencesKey("albumSortDescending")

val SongFilterKey = stringPreferencesKey("songFilter")
val ArtistFilterKey = stringPreferencesKey("artistFilter")
val AlbumFilterKey = stringPreferencesKey("albumFilter")

val LyricsScrollKey = booleanPreferencesKey("lyricsScrollKey")
val LyricsTextSizeKey = floatPreferencesKey("lyricsTextSizeKey")
val LyricsLineSpacingKey = floatPreferencesKey("lyricsLineSpacingKey")
val LyricsRomanizeJapaneseKey = booleanPreferencesKey("lyricsRomanizeJapaneseKey")
val LyricsRomanizeKoreanKey = booleanPreferencesKey("lyricsRomanizeKoreanKey")
val AppFontKey = stringPreferencesKey("appFont")
val ThemePresetKey = stringPreferencesKey("themePreset")
val NavBarScaleKey = floatPreferencesKey("navBarScale")

val ArtistViewTypeKey = stringPreferencesKey("artistViewType")
val AlbumViewTypeKey = stringPreferencesKey("albumViewType")
val PlaylistViewTypeKey = stringPreferencesKey("playlistViewType")

val PlaylistEditLockKey = booleanPreferencesKey("playlistEditLock")
val QuickPicksKey = stringPreferencesKey("discover")
val PreferredLyricsProviderKey = stringPreferencesKey("lyricsProvider")
val QueueEditLockKey = booleanPreferencesKey("queueEditLock")

val LyricFontSizeKey = intPreferencesKey("lyricFontSize")
val fullScreenLyricsKey = booleanPreferencesKey("fullScreenLyrics")
val EnableNewLyricsScreenKey = booleanPreferencesKey("enable_new_lyrics_screen")

val PlayPauseButtonShapeKey = stringPreferencesKey("playPauseButtonShape")
const val DefaultPlayPauseButtonShape = "Circle"
val SmallButtonsShapeKey = stringPreferencesKey("smallButtonsShape")
const val DefaultSmallButtonsShape = "Circle"

val MiniPlayerThumbnailShapeKey = stringPreferencesKey("miniPlayerThumbnailShape")
const val DefaultMiniPlayerThumbnailShape = "Circle"

enum class LibraryViewType {
    LIST,
    GRID,
    ;

    fun toggle() =
        when (this) {
            LIST -> GRID
            GRID -> LIST
        }
}

enum class SongFilter {
    LIBRARY,
    LIKED,
    DOWNLOADED
}

enum class ArtistFilter {
    LIBRARY,
    LIKED
}

enum class AlbumFilter {
    LIBRARY,
    LIKED
}

enum class SongSortType {
    CREATE_DATE,
    NAME,
    ARTIST,
    PLAY_TIME,
}

enum class PlaylistSongSortType {
    CUSTOM,
    CREATE_DATE,
    NAME,
    ARTIST,
    PLAY_TIME,
}

enum class AutoPlaylistSongSortType {
    CREATE_DATE,
    NAME,
    ARTIST,
    PLAY_TIME,
}

enum class ArtistSortType {
    CREATE_DATE,
    NAME,
    SONG_COUNT,
    PLAY_TIME,
}

enum class ArtistSongSortType {
    CREATE_DATE,
    NAME,
    PLAY_TIME,
}

enum class AlbumSortType {
    CREATE_DATE,
    NAME,
    ARTIST,
    YEAR,
    SONG_COUNT,
    LENGTH,
    PLAY_TIME,
}

enum class PlaylistSortType {
    NAME,
    SONG_COUNT,
    LAST_UPDATED,
}

enum class MixSortType {
    CREATE_DATE,
    NAME,
    LAST_UPDATED,
}

enum class GridItemSize {
    SMALL,
    BIG,
}

enum class MyTopFilter {
    ALL_TIME,
    DAY,
    WEEK,
    MONTH,
    YEAR,
    ;

    fun toTimeMillis(): Long =
        when (this) {
            DAY ->
                LocalDateTime
                    .now()
                    .minusDays(1)
                    .toInstant(ZoneOffset.UTC)
                    .toEpochMilli()

            WEEK ->
                LocalDateTime
                    .now()
                    .minusWeeks(1)
                    .toInstant(ZoneOffset.UTC)
                    .toEpochMilli()

            MONTH ->
                LocalDateTime
                    .now()
                    .minusMonths(1)
                    .toInstant(ZoneOffset.UTC)
                    .toEpochMilli()

            YEAR ->
                LocalDateTime
                    .now()
                    .minusMonths(12)
                    .toInstant(ZoneOffset.UTC)
                    .toEpochMilli()

            ALL_TIME -> 0
        }
}

enum class QuickPicks {
    QUICK_PICKS,
    LAST_LISTEN,
}

enum class PreferredLyricsProvider {
    LRCLIB,
    KUGOU,
}

enum class PlayerBackgroundStyle {
    DEFAULT,
    GRADIENT,
    BLUR,
    FLUID,
}

enum class PlayerButtonsStyle {
    DEFAULT,
    PRIMARY,
    TERTIARY
}

val TopSize = stringPreferencesKey("topSize")
val HistoryDuration = floatPreferencesKey("historyDuration")

val PlayerBackgroundStyleKey = stringPreferencesKey("playerBackgroundStyle")
val ShowLyricsKey = booleanPreferencesKey("showLyrics")
val TranslateLyricsKey = booleanPreferencesKey("translateLyrics")

val PlayerVolumeKey = floatPreferencesKey("playerVolume")
val EqualizerEnabledKey = booleanPreferencesKey("equalizerEnabled")
val RepeatModeKey = intPreferencesKey("repeatMode")
val PlayerButtonsStyleKey = stringPreferencesKey("player_buttons_style")

val SearchSourceKey = stringPreferencesKey("searchSource")
val SwipeThumbnailKey = booleanPreferencesKey("swipeThumbnail")

enum class SearchSource {
    LOCAL,
    ONLINE,
    ;

    fun toggle() =
        when (this) {
            LOCAL -> ONLINE
            ONLINE -> LOCAL
        }
}

val VisitorDataKey = stringPreferencesKey("visitorData")
val DataSyncIdKey = stringPreferencesKey("dataSyncId")
val AccountPhotoUrlKey = stringPreferencesKey("account_photo_url")
val InnerTubeCookieKey = stringPreferencesKey("innerTubeCookie")
val LastBackupTimestampKey = longPreferencesKey("last_backup_timestamp")
val AccountNameKey = stringPreferencesKey("accountName")
val AccountEmailKey = stringPreferencesKey("accountEmail")
val AccountChannelHandleKey = stringPreferencesKey("accountChannelHandle")
val UseLoginForBrowse = booleanPreferencesKey("useLoginForBrowse")
val DisableBlurKey = booleanPreferencesKey("disableBlur")

val LanguageCodeToName =
    mapOf(
        "af" to "Afrikaans",
        "az" to "Azərbaycan",
        "id" to "Bahasa Indonesia",
        "ms" to "Bahasa Malaysia",
        "ca" to "Català",
        "cs" to "Čeština",
        "da" to "Dansk",
        "de" to "Deutsch",
        "et" to "Eesti",
        "en-GB" to "English (UK)",
        "en" to "English (US)",
        "es" to "Español (España)",
        "es-419" to "Español (Latinoamérica)",
        "eu" to "Euskara",
        "fil" to "Filipino",
        "fr" to "Français",
        "fr-CA" to "Français (Canada)",
        "gl" to "Galego",
        "hr" to "Hrvatski",
        "zu" to "IsiZulu",
        "is" to "Íslenska",
        "it" to "Italiano",
        "sw" to "Kiswahili",
        "lt" to "Lietuvių",
        "hu" to "Magyar",
        "nl" to "Nederlands",
        "no" to "Norsk",
        "or" to "Odia",
        "uz" to "O'zbe",
        "pl" to "Polski",
        "pt-PT" to "Português",
        "pt" to "Português (Brasil)",
        "ro" to "Română",
        "sq" to "Shqip",
        "sk" to "Slovenčina",
        "sl" to "Slovenščina",
        "fi" to "Suomi",
        "sv" to "Svenska",
        "bo" to "Tibetan བོད་སྐད།",
        "vi" to "Tiếng Việt",
        "tr" to "Türkçe",
        "bg" to "Български",
        "ky" to "Кыргызча",
        "kk" to "Қазақ Тілі",
        "mk" to "Македонски",
        "mn" to "Монгол",
        "ru" to "Русский",
        "sr" to "Српски",
        "uk" to "Українська",
        "el" to "Ελληνικά",
        "hy" to "Հայերեն",
        "iw" to "עברית",
        "ur" to "اردو",
        "ar" to "العربية",
        "fa" to "فارسی",
        "ne" to "नेपाली",
        "mr" to "मराठी",
        "hi" to "हिन्दी",
        "bn" to "বাংলা",
        "pa" to "ਪੰਜਾਬੀ",
        "gu" to "ગુજરાતી",
        "ta" to "தமிழ்",
        "te" to "తెలుగు",
        "kn" to "ಕನ್ನಡ",
        "ml" to "മലയാളം",
        "si" to "සිංහල",
        "th" to "ภาษาไทย",
        "lo" to "ລາວ",
        "my" to "ဗမာ",
        "ka" to "ქართული",
        "am" to "አማርኛ",
        "km" to "ខ្មែរ",
        "zh-CN" to "中文 (简体)",
        "zh-TW" to "中文 (繁體)",
        "zh-HK" to "中文 (香港)",
        "ja" to "日本語",
        "ko" to "한국어",
    )

val CountryCodeToName =
    mapOf(
        "DZ" to "Algeria", "AR" to "Argentina", "AU" to "Australia", "AT" to "Austria",
        "AZ" to "Azerbaijan", "BH" to "Bahrain", "BD" to "Bangladesh", "BY" to "Belarus",
        "BE" to "Belgium", "BO" to "Bolivia", "BA" to "Bosnia and Herzegovina", "BR" to "Brazil",
        "BG" to "Bulgaria", "KH" to "Cambodia", "CA" to "Canada", "CL" to "Chile",
        "HK" to "Hong Kong", "CO" to "Colombia", "CR" to "Costa Rica", "HR" to "Croatia",
        "CY" to "Cyprus", "CZ" to "Czech Republic", "DK" to "Denmark", "DO" to "Dominican Republic",
        "EC" to "Ecuador", "EG" to "Egypt", "SV" to "El Salvador", "EE" to "Estonia",
        "FI" to "Finland", "FR" to "France", "GE" to "Georgia", "DE" to "Germany",
        "GH" to "Ghana", "GR" to "Greece", "GT" to "Guatemala", "HN" to "Honduras",
        "HU" to "Hungary", "IS" to "Iceland", "IN" to "India", "ID" to "Indonesia",
        "IQ" to "Iraq", "IE" to "Ireland", "IL" to "Israel", "IT" to "Italy",
        "JM" to "Jamaica", "JP" to "Japan", "JO" to "Jordan", "KZ" to "Kazakhstan",
        "KE" to "Kenya", "KR" to "South Korea", "KW" to "Kuwait", "LA" to "Lao",
        "LV" to "Latvia", "LB" to "Lebanon", "LY" to "Libya", "LI" to "Liechtenstein",
        "LT" to "Lithuania", "LU" to "Luxembourg", "MK" to "Macedonia", "MY" to "Malaysia",
        "MT" to "Malta", "MX" to "Mexico", "ME" to "Montenegro", "MA" to "Morocco",
        "NP" to "Nepal", "NL" to "Netherlands", "NZ" to "New Zealand", "NI" to "Nicaragua",
        "NG" to "Nigeria", "NO" to "Norway", "OM" to "Oman", "PK" to "Pakistan",
        "PA" to "Panama", "PG" to "Papua New Guinea", "PY" to "Paraguay", "PE" to "Peru",
        "PH" to "Philippines", "PL" to "Poland", "PT" to "Portugal", "PR" to "Puerto Rico",
        "QA" to "Qatar", "RO" to "Romania", "RU" to "Russian Federation", "SA" to "Saudi Arabia",
        "SN" to "Senegal", "RS" to "Serbia", "SG" to "Singapore", "SK" to "Slovakia",
        "SI" to "Slovenia", "ZA" to "South Africa", "ES" to "Spain", "LK" to "Sri Lanka",
        "SE" to "Sweden", "CH" to "Switzerland", "TW" to "Taiwan", "TZ" to "Tanzania",
        "TH" to "Thailand", "TN" to "Tunisia", "TR" to "Turkey", "UG" to "Uganda",
        "UA" to "Ukraine", "AE" to "United Arab Emirates", "GB" to "United Kingdom",
        "US" to "United States", "UY" to "Uruguay", "VE" to "Venezuela (Bolivarian Republic)",
        "VN" to "Vietnam", "YE" to "Yemen", "ZW" to "Zimbabwe",
    )
